<script src="<?php echo isset($is_dashboard) ? '../' : ''; ?>js/main.js"></script>
</body>
</html>
